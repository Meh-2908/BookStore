package com.BookStore.BookStore.Controller;
import com.BookStore.BookStore.Entity.Book;
import com.BookStore.BookStore.Entity.MyBooks;
import com.BookStore.BookStore.Service.BookService;
import com.BookStore.BookStore.Service.MyBooksService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import java.util.List;
import org.springframework.ui.Model;



@Controller
public class BookController
{
    @Autowired
    private BookService service;


    @Autowired
    private MyBooksService myBooksService;

    @GetMapping("/")
    public String home()
    {
        return "home";
    }

    @GetMapping("/book-reg")
    public String bookRegister()
    {
        return "bookReg";
    }

    @GetMapping("/available-books")
    public ModelAndView getAllBook()
    {
        List<Book>list=service.getAllBooks();
        /*ModelAndView m = new ModelAndView();
        m.setViewName("availableBooks");
        m.addObject("book",list);*/
        return new ModelAndView("availableBooks","book",list);
    }

    @PostMapping("/save")
    public  String addBook(@ModelAttribute Book b)
    {
        service.save(b);
        return "redirect:/available-books";
    }

    @GetMapping("/my-books")
    public String getMyBooks(Model model)
    {
        List<MyBooks> list = myBooksService.getAllMyBooks();
        model.addAttribute("book",list);

        return "myBooks";
    }

    @RequestMapping("/mylist/{id}")
    public String getMyList(@PathVariable("id") int id) {
        Book b = service.getBookBYId(id);
        MyBooks mb = new MyBooks(b.getName(), b.getAuthor(), b.getPrice());
        myBooksService.saveMyBooks(mb);
        return "redirect:/available-books";
    }


}
