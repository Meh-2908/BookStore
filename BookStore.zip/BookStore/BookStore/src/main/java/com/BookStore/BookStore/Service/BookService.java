package com.BookStore.BookStore.Service;
import com.BookStore.BookStore.Entity.Book;
import com.BookStore.BookStore.Repo.BookRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookService
{
    @Autowired

    private BookRepo bookRepo;
    public void save(Book b)
    {
        bookRepo.save(b);
    }

    public List<Book> getAllBooks()
    {
        return bookRepo.findAll();
    }

    public Book getBookBYId(int id) {
        return bookRepo.findById(id).get();
    }

}
