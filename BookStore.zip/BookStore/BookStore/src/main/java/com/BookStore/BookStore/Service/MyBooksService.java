package com.BookStore.BookStore.Service;


import com.BookStore.BookStore.Entity.MyBooks;
import com.BookStore.BookStore.Repo.MyBookRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MyBooksService
{
    @Autowired
    private MyBookRepo mybook;

    public void saveMyBooks(MyBooks books)
    {
        mybook.save(books);
    }

    public List<MyBooks> getAllMyBooks()
    {
        return mybook.findAll();
    }


    public void deleteById(int id)
    {
        mybook.deleteById(id);
    }
}
