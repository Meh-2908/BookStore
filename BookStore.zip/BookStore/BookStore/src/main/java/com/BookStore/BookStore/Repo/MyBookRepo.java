package com.BookStore.BookStore.Repo;

import com.BookStore.BookStore.Entity.MyBooks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface MyBookRepo  extends JpaRepository<MyBooks,Integer>
{

}
